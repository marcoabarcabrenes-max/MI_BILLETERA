package com.mibilletera.app

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import java.text.NumberFormat
import java.util.*

data class Movimiento(val tipo:String, val monto:Long, val categoria:String, val nota:String, val fecha:String)

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("mi_billetera", Context.MODE_PRIVATE) }
    private val movimientos = mutableListOf<Movimiento>()
    private lateinit var saldo: TextView
    private lateinit var ingresos: TextView
    private lateinit var gastos: TextView
    private lateinit var lista: LinearLayout

    private fun money(n: Long): String = NumberFormat.getCurrencyInstance(Locale("es","CR")).format(n).replace("CRC","₡").replace(" ","")
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cargar()
        construir()
        actualizar()
    }

    private fun cargar() {
        val raw = prefs.getString("movimientos","") ?: ""
        if(raw.isBlank()) return
        raw.split("\n").forEach { s ->
            val a=s.split("|")
            if(a.size>=5) movimientos.add(Movimiento(a[0],a[1].toLongOrNull()?:0,a[2],a[3],a[4]))
        }
    }

    private fun guardar() {
        prefs.edit().putString("movimientos",movimientos.joinToString("\n") { listOf(it.tipo,it.monto,it.categoria,it.nota,it.fecha).joinToString("|") }).apply()
    }

    private fun construir() {
        val scroll=ScrollView(this)
        val base=LinearLayout(this); base.orientation=LinearLayout.VERTICAL; base.setPadding(dp(16),dp(12),dp(16),dp(90))
        base.setBackgroundColor(Color.rgb(7,20,38))
        val title=TextView(this).apply { text="👛\nMI BILLETERA"; textSize=27f; setTextColor(Color.rgb(242,200,75)); gravity=Gravity.CENTER; setPadding(0,0,0,dp(10)) }
        base.addView(title)

        val card=LinearLayout(this); card.orientation=LinearLayout.VERTICAL; card.setPadding(dp(20),dp(18),dp(20),dp(18)); card.setBackgroundColor(Color.rgb(21,52,86))
        saldo=TextView(this).apply { textSize=38f; setTextColor(Color.WHITE); gravity=Gravity.CENTER }
        val lab=TextView(this).apply { text="SALDO DISPONIBLE"; textSize=14f; setTextColor(Color.LTGRAY); gravity=Gravity.CENTER }
        card.addView(lab); card.addView(saldo)
        base.addView(card, LinearLayout.LayoutParams(-1,dp(125)).apply{setMargins(0,dp(8),0,dp(12))})

        val stats=LinearLayout(this); stats.orientation=LinearLayout.HORIZONTAL
        ingresos=TextView(this).apply{textSize=18f;gravity=Gravity.CENTER;setTextColor(Color.rgb(53,199,89))}
        gastos=TextView(this).apply{textSize=18f;gravity=Gravity.CENTER;setTextColor(Color.rgb(255,90,82))}
        stats.addView(ingresos,LinearLayout.LayoutParams(0,dp(75),1f)); stats.addView(gastos,LinearLayout.LayoutParams(0,dp(75),1f))
        base.addView(stats)

        val actions=LinearLayout(this); actions.orientation=LinearLayout.HORIZONTAL
        val bi=boton("👛➕\nINGRESO",Color.rgb(25,145,65)){dialogo("ingreso")}
        val be=boton("👛➖\nGASTO",Color.rgb(190,55,48)){dialogo("gasto")}
        actions.addView(bi,LinearLayout.LayoutParams(0,dp(115),1f).apply{setMargins(0,dp(8),dp(6),dp(8))})
        actions.addView(be,LinearLayout.LayoutParams(0,dp(115),1f).apply{setMargins(dp(6),dp(8),0,dp(8))})
        base.addView(actions)

        val tools=LinearLayout(this); tools.orientation=LinearLayout.HORIZONTAL
        listOf("📋\nMOVIMIENTOS","📊\nRESUMEN","🎯\nPRESUPUESTO","⚙️\nAJUSTES").forEach { t ->
            val b=boton(t,Color.rgb(18,41,66)){ if(t.startsWith("📊")) resumen() else if(t.startsWith("📋")) movimientosDialog() else Toast.makeText(this,"Esta sección se ampliará en la próxima versión.",Toast.LENGTH_SHORT).show() }
            tools.addView(b,LinearLayout.LayoutParams(0,dp(80),1f).apply{setMargins(dp(2),0,dp(2),0)})
        }
        base.addView(tools)
        val head=TextView(this).apply{text="🕘  MOVIMIENTOS RECIENTES";textSize=16f;setTextColor(Color.rgb(242,200,75));setPadding(0,dp(18),0,dp(8))}
        base.addView(head)
        lista=LinearLayout(this);lista.orientation=LinearLayout.VERTICAL;base.addView(lista)
        scroll.addView(base);setContentView(scroll)
    }

    private fun boton(text:String,bg:Int,click:()->Unit):Button=Button(this).apply{
        this.text=text;textSize=12f;setTextColor(Color.WHITE);setBackgroundColor(bg);setOnClickListener{click()}
    }

    private fun dialogo(tipo:String){
        val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL;box.setPadding(dp(20),dp(8),dp(20),0)
        val monto=EditText(this).apply{hint="Monto en colones";inputType=2}
        val cat=EditText(this).apply{hint="Categoría (comida, salario, etc.)"}
        val nota=EditText(this).apply{hint="Descripción (opcional)"}
        box.addView(monto);box.addView(cat);box.addView(nota)
        AlertDialog.Builder(this).setTitle(if(tipo=="ingreso")"💵 Registrar ingreso" else "💸 Registrar gasto").setView(box)
            .setPositiveButton("GUARDAR"){_,_->
                val n=monto.text.toString().toLongOrNull()?:0
                if(n>0){movimientos.add(0,Movimiento(tipo,n,cat.text.toString().ifBlank{"Otros"},nota.text.toString(),java.text.SimpleDateFormat("dd/MM/yyyy",Locale("es","CR")).format(Date())));guardar();actualizar()}
            }.setNegativeButton("CANCELAR",null).show()
    }

    private fun actualizar(){
        val inc=movimientos.filter{it.tipo=="ingreso"}.sumOf{it.monto};val gas=movimientos.filter{it.tipo=="gasto"}.sumOf{it.monto}
        saldo.text=money(inc-gas);ingresos.text="⬆️  ${money(inc)}\nINGRESOS";gastos.text="⬇️  ${money(gas)}\nGASTOS"
        lista.removeAllViews()
        if(movimientos.isEmpty()){lista.addView(TextView(this).apply{text="Aún no hay movimientos.\nUsa los botones para comenzar.";gravity=Gravity.CENTER;setTextColor(Color.LTGRAY);setPadding(0,dp(20),0,dp(20))})}
        else movimientos.take(8).forEach{m->lista.addView(TextView(this).apply{text="${if(m.tipo=="ingreso")"⬆️" else "⬇️"}  ${m.nota.ifBlank{m.categoria}}     ${if(m.tipo=="ingreso")"+" else "−"}${money(m.monto)}\n     ${m.categoria} · ${m.fecha}";textSize=15f;setTextColor(Color.WHITE);setPadding(dp(8),dp(10),dp(8),dp(10))})}
    }
    private fun resumen(){val inc=movimientos.filter{it.tipo=="ingreso"}.sumOf{it.monto};val gas=movimientos.filter{it.tipo=="gasto"}.sumOf{it.monto};AlertDialog.Builder(this).setTitle("📊 RESUMEN").setMessage("Ingresos: ${money(inc)}\nGastos: ${money(gas)}\nSaldo: ${money(inc-gas)}").setPositiveButton("OK",null).show()}
    private fun movimientosDialog(){if(movimientos.isEmpty()){Toast.makeText(this,"No hay movimientos todavía.",Toast.LENGTH_SHORT).show();return};AlertDialog.Builder(this).setTitle("📋 MOVIMIENTOS").setMessage(movimientos.joinToString("\n\n"){ "${if(it.tipo=="ingreso")"⬆️" else "⬇️"} ${it.categoria}: ${money(it.monto)}\n${it.nota} · ${it.fecha}" }).setPositiveButton("OK",null).show()}
}
